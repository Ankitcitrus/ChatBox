var app=angular.module("NemfApp");
app.directive("mandatoryDir",function(){
    var id1=angular.element(document.getElementsByClassName('error1'));
    var id2=angular.element(document.getElementsByClassName('error2'));
function myFunc(element,attributes){
element.css("border", "1px solid rgb(206, 31, 31)");
    var linkfunction=function($scope,element,attributes){
    element.on('blur',function(){
        if((element.val() =="")){
            if(element.hasClass("user"))
            id1.append("Field is empty.");
            else
                id2.append("Field is empty.");
        }
          
        else{
             if(element.hasClass("user"))
            id1.empty();
            else
                id2.empty();
             
        }
           
       
        //id.append("error");
      // element[0].append("<p>Test</p>");
    })
    }
return linkfunction;
}
    return{
restrict:'A',
compile:myFunc,
scope:false

}


})