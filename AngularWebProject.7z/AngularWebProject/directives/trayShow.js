var app=angular.module("NemfApp");
app.directive("trayShow",function(){
var directive={};
    directive.restrict="EA";
    directive.scope=true;
    directive.compile=function(){
    var linkfunction=function(){
    
    }
    directive.controller:
    };
    directive.templateUrl="../view/trayDirective.html";

})