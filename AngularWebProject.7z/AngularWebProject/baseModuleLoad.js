(function(){
angular.module("NemfApp",["ui.router"]);

})()