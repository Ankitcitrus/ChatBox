var app=angular.module("NemfApp");
app.controller('DashboardController',function(){
var a=this;
     var bucArray = $.jStorage.get("bucTemplateList");
    
    var data=$.jStorage.get("autheticate" );
    a.user=data.name;
    a.password=data.password;
})