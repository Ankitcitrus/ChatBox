var app=angular.module("NemfApp");
app.config(function($stateProvider,$urlRouterProvider){
$urlRouterProvider.otherwise("/login");
    $stateProvider.state('login',{
    url:"/login",
    controller:"LoginController",
    controllerAs:"LoginCtrl",
    templateUrl:"../view/login.html"
    })
    .state('dashboard',{
    url:"/dashboard",
    controller:"DashboardController",
    controllerAs:"DashCtrl",
    templateUrl:"../view/dashboard.html"
    })
    
});
app.run(function(solutionConfiguration){
solutionConfiguration.$NGBrowserTestingMode=false;
})
app.controller('LoginController',function($location,$state,loadData){
var a=this;
    a.name="";
     a.password="";
    
    
    a.authenticate=function(){
        var userObj={};
       userObj.name=a.name;
        userObj.password=a.password;
        loadData.getfunction().then(function(data){
         $.jStorage.set("autheticate",userObj );
        $state.go('dashboard');
        });
       
    
    }
    
})