var app=angular.module("NemfApp");
app.service("loadData",function($http,$q){
var defer = $q.defer();
this.getfunction=getfunction;
    function getfunction(){
        var defer1=$q.defer();
    $http.get('Bucdata') .success(function(data) {
         defer1.resolve(data);
          processBUCTemplate(data);
        })
       .error(function() {
           defer.reject('could not find someFile.json');
        });
    return defer1.promise;
    }
function processBUCTemplate(bucConfigXml){
      xmlDoc = $.parseXML(bucConfigXml);
      $xml = $(xmlDoc);
      var bucTemplateList = new Array();
      $xml.find("buc").each(function(){
          var bucName = $(this).attr("name");
          var encryptionRequired = $(this).attr("encryptionRequired");
          var bucTemplate = new NGBusinessUseCaseTemplate(bucName);
          if(encryptionRequired){
        	  bucTemplate.encryptionRequired= encryptionRequired;
          }
         
          $(this).find("Tray").each(function(){
              var trayName = $(this).attr("name");
              var tray = new NGTray(trayName);
              var trayTemplate = new NGTrayTemplate(trayName);
              if($(this).attr("visible") != "undefined"){
                  trayTemplate.isVisible = $(this).attr("visible");
                  tray.isVisible = $(this).attr("visible");
              }
              if($(this).attr("maxInstanceAge") != "undefined"){
                  trayTemplate.maxInstanceAge = $(this).attr("maxInstanceAge");
                  tray.maxInstanceAge = $(this).attr("maxInstanceAge");
              }
              if($(this).attr("syncInstancesOnLoad") != "undefined"){
                  trayTemplate.syncInstancesOnLoad = $(this).attr("syncInstancesOnLoad");
                  tray.syncInstancesOnLoad = $(this).attr("syncInstancesOnLoad"); 
              }
              if($(this).attr("disallowSubmissions") != "undefined"){
                  trayTemplate.disallowSubmissions = $(this).attr("disallowSubmissions");
                  tray.disallowSubmissions = $(this).attr("disallowSubmissions");
              }
              if($(this).attr("disallowDataUpdates") != "undefined"){
                  trayTemplate.disallowDataUpdates = $(this).attr("disallowDataUpdates");
                  tray.disallowDataUpdates = $(this).attr("disallowDataUpdates");
              }
              bucTemplate.trays.push(trayTemplate);
            //SQLiteStorage Implementation for trays.
              //Modified by Suruchi Sinha on 08/03/2016;
              if(trayName.toLowerCase() != "add new"){
            	   var trayObj=$.jStorage.get(bucName+"Tray"+"."+trayName);
            		  if(typeof trayObj!=Object){
            			   $.jStorage.set(bucName+"Tray"+"."+trayName, JSON.stringify(tray));
            		  }
            	 
//                   if(!NGCommonUtils.checkValue($NGjStorage.get(bucName+"."+trayName))){
//                       $NGjStorage.set(bucName+"."+trayName, tray);
//                  }
              }
            });
      /*    $(this).find("form").each(function(){
              var formName = $(this).attr("name");
              var formTemplate = new NGFormTemplate(formName);
              formTemplate.markUp = $(this).find("Markup").text();
              formTemplate.model = $(this).find("Model").text();
              formName = bucTemplate.bucName+"_"+formName;
//              var processedHtml = processAttachments(formTemplate.markUp);
               $.jStorage.set(formName+"_markup",formTemplate.markUp);
               $.jStorage.set(formName+"_model_script", formTemplate.model);
              formTemplate.outputModelTemplate = NGFormUtils.createOutputModel($($.parseHTML(formTemplate.markUp)));
              bucTemplate.forms.push(formTemplate);
          });
          $(this).find("EnableThumbNail").each(function(){
              bucTemplate.enableThumbNail = JSON.parse($(this).text());
          });
          $(this).find("ThumbNailIdentity").each(function(){
              bucTemplate.thumbNailIdentity = $(this).text();
          });
          $(this).find("Attachment").each(function(){
              var attachmentName = $(this).attr("name");
              var attachmentTemplate = new NGAttachmentTemplate(attachmentName);
              attachmentTemplate.type = $(this).attr("type");
              attachmentTemplate.label = $(this).attr("label");
              attachmentTemplate.source = $(this).find("CaptureSource").attr("source");
              attachmentTemplate.attributes = $(this).find("CaptureSource").attr("attributes");
              bucTemplate.attachments.push(attachmentTemplate);
          });*/
          bucTemplateList.push(bucTemplate);
          if(!$.jStorage.get(bucName+"_InstanceList")){
               $.jStorage.set(bucName+"_InstanceList", new Array());
          }
      });
       $.jStorage.set("bucTemplateList", bucTemplateList);
     
  }
    

})