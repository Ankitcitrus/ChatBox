var app=angular.module("NemfApp");
app.service("solutionConfiguration",function(){

this.$NGServerEndPoint = "";
this.$NGServerWebSocketEndPoint = "";
this.$NGResendPendingRequestInterval = 120000;

this.$NGViewMarkUpFolder="views/";
this.$NGViewMarkUpNamePrefix="_";
this.$NGViewMarkUpNameSuffix="_view.js";

this.$NGViewModelScriptFolder="scripts/custom/runtime/viewscripts/";
this.$NGViewModelScriptPrefix="ng-";
this.$NGViewModelScriptSuffix="-view-script.js";
this.$NGInitialView = 'login';
this.$NGAppLockRequired = true;	
this.$NGIsSessionExpired = false;
this.$NGBrowserTestingMode = false;
this.$NGTesterIsEnable = true;
this.$NGFastResumeExcludedViews = ['login','root','forgotPassword','createProfile'];
this.$NGFastResumeEnabled = false;



})

