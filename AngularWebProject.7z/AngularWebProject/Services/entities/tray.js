


if (typeof (ngclientframework) == 'undefined')
    ngclientframework = {};

if (typeof (ngclientframework.tray) == 'undefined')
    ngclientframework.tray = function(trayName) {
    	
        this.trayName = trayName;
        this.bucInstances = ["java.util.HashSet"];
        this.isVisible;
        this.geoLocation; 
        this.maxInstanceAge;
        this.syncInstancesOnLoad;
        this.disallowSubmissions;
        this.disallowDataUpdates;
        this.trayHeaderFields = ["java.util.HashSet"]; 
    };


// export Organization's prototype to globals as JQuery object
NGTray = ngclientframework.tray;