



if (typeof (ngclientframework) == 'undefined')
    ngclientframework = {};

if (typeof (ngclientframework.businessUseCaseTemplate) == 'undefined')
    ngclientframework.businessUseCaseTemplate = function(bucName) {
    
        if (typeof (bucName) != 'undefined' && 
                typeof (bucName) != 'string') {
            throw "bucName should be an String";
            }
    
        this.bucName = bucName;
        this.trays = ["java.util.HashSet"];
        this.forms = ["java.util.HashSet"];
        this.attachments = ["java.util.HashSet"];
        this.indexingFields = ["java.util.HashSet"];
        this.encryptionRequired = false;
        this.parallelUpload = false;
        this.enableThumbNail = false;
        this.thumbNailIdentity;
        this.lastAccessDate = "";
        this.versionId;
        this.script;
    };

// export Organization's prototype to globals as JQuery object
NGBusinessUseCaseTemplate = ngclientframework.businessUseCaseTemplate;