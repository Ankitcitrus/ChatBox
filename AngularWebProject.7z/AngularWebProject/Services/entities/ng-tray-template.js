




if (typeof (ngclientframework) == 'undefined')
    ngclientframework = {};

if (typeof (ngclientframework.trayTemplate) == 'undefined')
    ngclientframework.trayTemplate = function(trayName) {
    
        if (typeof (trayName) != 'undefined' && 
                typeof (trayName) != 'string') {
            throw "trayName should be an String";
            }
        
        this.trayName = trayName;
        this.isVisible;
        this.maxInstanceAge;
        this.syncInstancesOnLoad;
        this.disallowSubmissions;
        this.disallowDataUpdates;
        this.trayHeaderFields = ["java.util.HashSet"]; 
    };


// export Organization's prototype to globals as JQuery object
NGTrayTemplate = ngclientframework.trayTemplate;