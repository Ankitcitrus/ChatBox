var product=require('../models/product');
var mongoose=require('mongoose');

var promise = mongoose.connect('mongodb://localhost:27017/Shopping', {
  useMongoClient: true,
  /* other options */
});
var products=[new product({
imagePath:'http://drop.ndtv.com/TECH/product_database/images/513201564925PM_635_general_mobile_4g.jpeg',
    title:'Samsung',
    description:'aaaaaa',
    price:2000
}),
   new product({
imagePath:'http://drop.ndtv.com/TECH/product_database/images/513201564925PM_635_general_mobile_4g.jpeg',
    title:'Samsung',
    description:'aaaaaa',
    price:3000
}),
             new product({
imagePath:'http://drop.ndtv.com/TECH/product_database/images/513201564925PM_635_general_mobile_4g.jpeg',
    title:'Samsung',
    description:'aaaaaa',
    price:2000
}),
             new product({
imagePath:'http://drop.ndtv.com/TECH/product_database/images/513201564925PM_635_general_mobile_4g.jpeg',
    title:'Samsung',
    description:'aaaaaa',
    price:2000
}),];
var done=0;
for(var i=0;i<products.length;i++){

products[i].save(function(err,result){
done++;
    if(done==products.length){
        exit();
    }
});
}
function exit(){
    mongoose.disconnect();
}
    
