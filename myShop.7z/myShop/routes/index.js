var express = require('express');
var router = express.Router();
var Cart=require('../models/cart');
var csrf=require('csurf');
var passport=require('passport');

var Product=require('../models/product');
/*var csrfprotection=csrf();
router.use(csrfprotection);
/* GET home page. */
router.get('/', function(req, res, next) {
     Product.find(function(err,docs){
         var productChunks=[];
         var chunkSize=3;
         for(var i=0;i<docs.length;i+=chunkSize){
         productChunks.push(docs.slice(i,i+chunkSize));
         }
        console.log(docs.length);
     res.render('shop/index', { title: 'Express' ,products:productChunks});
    });
 
});

router.get('/add-To-Cart/:id',function(req,res,next){
    var productId=req.params.id;
    console.log(productId);
    var cart=new Cart(req.session.cart?req.session.cart:{});
    Product.findById(productId,function(err,product){
        console.log(product);
    if(err){
        res.redirect('/');
    }
        console.log(product.id);
        cart.add(product,product.id);
        req.session.cart=cart;
         console.log( req.session.cart);
         res.redirect('/');
       
    });
});

router.get('/shopping-cart',function(req,res,next){
if(!req.session.cart){
    res.render('shop/shopping-cart',{products:null});
}
    var cart=new Cart(req.session.cart);
    res.render('shop/shopping-cart',{products:cart.generateArray(),totalPrice:cart.totalPrice});
});

router.get('/checkout',function(req,res,next){
if(!req.session.cart){
    res.redirect('/shopping-cart');
}
    var cart=new Cart(req.session.cart);
    res.render('shop/checkout',{totalPrice:cart.totalPrice});
});


module.exports = router;
