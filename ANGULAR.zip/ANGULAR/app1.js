(function(){


angular.module("turtleFacts",[]);//if not paass


})();