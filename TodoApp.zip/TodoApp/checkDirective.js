var a=angular.module("TodoList");
a.directive("checkLength",function(){
    
    function myfunc($scope,element,attributes,controller){
        element.on("keypress",function(e){
            if(e.which == 13) {
                element.css("background-color", "yellow");
                
                
                //$scope.dataCtrl.count1=6;
                $scope.$emit('_sortFinished','kk');
                
          }
        })
        $scope.changecount=function(){
            $scope.count1=3;
        }
     }
    var directive={};
    directive.restrict="EA";
    directive.link=myfunc;
    directive.transclude=true;
    directive.scope={
        count1:'@ankit',
        data:'=',
        myfunc:'&'
    };
    directive.controller= function ($scope) {
        
            console.log($scope);
        $scope.addition=function(){
            console.log("aa");
        }
        $scope.$on("_sortFinished", function(event, message){
     $scope.mydata="ff";
           $scope.$apply();
});
        $scope.$watch('mydata',function(){
  //s$scope.mydata="d";why it is not updating not able to communicate between the controller and link
});
        $scope.mydata="ankit";
        };
    directive.templateUrl="mydirective.html";
    return directive;

});
a.directive("checkData",function(){
    function myfunc1($scope,element,attributes,controller){
        element.on("click",function(e){
         controller.addition();
        });
       
     }
     var directive={};
    directive.require ='^checkLength';
    directive.restrict="EA";
    directive.link=myfunc1;
   directive.templateUrl="mydirective1.html";
    return directive;
})

