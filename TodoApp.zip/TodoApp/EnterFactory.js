var app=angular.module("TodoList");
app.factory("dataAddFactory",function(){
    addData=function(someData){
        data.push(someData);
    } 
    
    deleteData=function(){
        data.pop();
    }
    var factory={};
     var data=[];
    factory.addData=addData;
    factory.deleteData=deleteData;
    factory.data=data;
   return factory;
    
});