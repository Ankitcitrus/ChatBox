var a=angular.module("TodoList");
a.directive("enterPress",function($rootScope,dataAddFactory){
    
    function myfunc($scope,element,attributes){
        element.on("keypress",function(e){
            if(e.which == 13) {
                //dataAddFactory.addData("pp");
                $rootScope.$broadcast('adddata',"AA");
             //alert('You pressed enter!');
          }
        })
     }
    var directive={};
    directive.restrict="EA";
    directive.link=myfunc;
    directive.scope=false;
    directive.controller= function ($scope) {
            console.log($scope);
        }
    return directive;

})
