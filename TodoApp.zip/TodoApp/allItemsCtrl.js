var app=angular.module("TodoList");
var someFunction = function($rootScope, $http) {
    return "called!";
};
 
app.run(function($rootScope, $injector) {
 
    $rootScope.annotations = $injector.annotate(someFunction);
    $rootScope.message = $injector.invoke(someFunction);
 
});
app.controller("dataEnterController",function(dataAddFactory,$scope,myfirst){
    console.log($scope);
    var a=this;
    a.data=[];
    a.count1=2;
    a.count2=myfirst.url;
    a.customers = [
        {
            name: 'David',
            street: '1234 Anywhere St.'
        },
        {
            name: 'Tina',
            street: '1800 Crest St.'
        },
        {
            name: 'Michelle',
            street: '890 Main St.'
        }
    ];
    a.additems=function(){
        a.count1++;
    }
    $scope.$on('adddata',function(data){
        dataAddFactory.addData(data.name);
        a.data=dataAddFactory.data;
        $scope.$apply();
    })
    
});
app.provider("myfirst",function(){
    var url="";
    this.config=function(dataurl){
        url=dataurl;
    }
    this.$get=function(){
        var myinnerdir={};
        myinnerdir.url=url;
        return myinnerdir;
    }
});
app.config(function(myfirstProvider){
    myfirstProvider.config("ankit");
})