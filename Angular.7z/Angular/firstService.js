(function(){
angular.module("turtleFacts").factory("Quizfact",QuizMetrics);

    function QuizMetrics(){
       var QuizObj={};
        QuizObj.quizActive=false;
        QuizObj.changeFunc=changeFunc;
        return QuizObj;
        
    function changeFunc(state){
    QuizObj.quizActive=state;
    }
    }
}());