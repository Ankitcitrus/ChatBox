(function(){
angular.module("turtleFacts").controller("quizCtrl",quizController);
    quizController.$inject=["Quizfact","Datafact"];
    function quizController(Quizfact,Datafact){
    var vm=this;
        vm.Quizfact=Quizfact;
        vm.Datafact=Datafact;
        vm.activeQuestion=0;
    }
})();