(function(){

    angular.module("Routing",["ui.router"])
            .config(function($stateProvider,$urlMatcherFactoryProvider,$urlRouterProvider){
        $urlRouterProvider.otherwise("/home");
       $urlMatcherFactoryProvider.caseInsensitive(true);
    $stateProvider.state("home",{
                        url:"/home",
                        templateUrl:"partialTemplate/home.html",
                        controller:"homeController",
                        controllerAs:"homeCtrl"
                   })
                  .state("students",{
                         url:"/students",
                         templateUrl:"partialTemplate/student.html",
                         controller:"studentController",
                         controllerAs:"studentCtrl"
                   })
                  .state("studentdetail",{
                      url:"/students/:id",
                      templateUrl:"partialTemplate/studentName.html",
                      controller:"studentNameController"
                   })
                   .state("searchDetail",{
                      url:"/Studentsearch/:name",
                      templateUrl:"partialTemplate/studentsearch.html",
                      controller:"studentSearchController"
                   })
                 /* .when("/students/:id",{
                      templateUrl:"partialTemplate/studentName.html",
                      controller:"studentNameController"
                   })
                   .when("/Studentsearch/:name?",{
                      templateUrl:"partialTemplate/studentsearch.html",
                      controller:"studentSearchController"
                   })
    .otherwise({
    redirectTo:"/home"
    })*/
    //$locationProvider.html5Mode(true);
    })
    .controller("homeController",function(){
    this.message="Home Page";
    })
    .controller("studentController",function($scope,$state){
         var a=this;
         a.searchData=function(){
        $state.go("searchDetail",{name:a.name});
        }
          a.reloadData=function(){
        $state.reload();
          }
   /* $scope.$on("$routeChangeStart",function(event,next,current){
    if(!confirm("aaaaaa"+next.$$route.originalPath))
    event.preventDefault();
    });
        
      
        a.searchData=function(){
        if(a.name){
            $location.url("/Studentsearch/"+a.name);
        }
            else{
            $location.url("/Studentsearch/");
            }
        }
        
        a.reloadData=function(){
        $route.reload();
        }*/
        a.studentArray=["aa","ss","dd"];
    })
    .controller("studentSearchController",function($scope,$stateParams){
     $scope.name=$stateParams.name;
    })
    .controller("studentNameController",function($scope,$stateParams){
    $scope.Id=$stateParams.id;
    })


}());